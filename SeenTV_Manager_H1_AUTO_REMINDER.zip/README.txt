SeenTV Manager V2
Branding SeenTV sahaja. Tambahan: dashboard kewangan, statistik bulanan, pelanggan, renewal, WhatsApp, resit, transaksi, backup/restore, PIN dan auto-lock selepas 5 minit tidak aktif.
Data disimpan pada peranti/browser. Backup sebelum clear storage atau tukar telefon.
